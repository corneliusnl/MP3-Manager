/* id3 Renamer
 * genre.h - Header for music genres
 * Copyright (C) 1998  Robert Alto (badcrc@tscnet.com)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
 * USA.
 */

#ifndef __GENRE_H__
#define __GENRE_H__

char *genre_table[] = {"Blues",
                       "Classic Rock",
                       "Country",
                       "Dance",
                       "Disco",
                       "Funk",
                       "Grunge",
                       "Hip-Hop",
                       "Jazz",
                       "Metal",
                       "New Age",
                       "Oldies",
                       "Other",
                       "Pop",
                       "R&B",
                       "Rap",
                       "Reggae",
                       "Rock",
                       "Techno",
                       "Industrial",
                       "Alternative",
                       "Ska",
                       "Death Metal",
                       "Pranks",
                       "Soundtrack",
                       "Euro-Techno",
                       "Ambient",
                       "Trip-Hop",
                       "Vocal",
                       "Jazz+Funk",
                       "Fusion",
                       "Trance",
                       "Classical",
                       "Instrumental",
                       "Acid",
                       "House",
                       "Game",
                       "Sound Clip",
                       "Gospel",
                       "Noise",
                       "Alt. Rock",
                       "Bass",
                       "Soul",
                       "Punk",
                       "Space",
                       "Meditative",
                       "Instrum. Pop",
                       "Instrum. Rock",
                       "Ethnic",
                       "Gothic",
                       "Darkwave",
                       "Techno-Indust.",
                       "Electronic",
                       "Pop-Folk",
                       "Eurodance",
                       "Dream",
                       "Southern Rock",
                       "Comedy",
                       "Cult",
                       "Gangsta",
                       "Top 40",
                       "Christian Rap",
                       "Pop/Funk",
                       "Jungle",
                       "Native American",
                       "Cabaret",
                       "New Wave",
                       "Psychadelic",
                       "Rave",
                       "Showtunes",
                       "Trailer",
                       "Lo-Fi",
                       "Tribal",
                       "Acid Punk",
                       "Acid Jazz",
                       "Polka",
                       "Retro",
                       "Musical",
                       "Rock & Roll",
                       "Hard Rock",
                       "Folk",
                       "Folk/Rock",
                       "National Folk",
                       "Swing",
                       "Fusion",
                       "Bebob",
                       "Latin",
                       "Revival",
                       "Celtic",
                       "Bluegrass",
                       "Avantgarde",
                       "Gothic Rock",
                       "Progress. Rock",
                       "Psychadel. Rock",
                       "Symphonic Rock",
                       "Slow Rock",
                       "Big Band",
                       "Chorus",
                       "Easy Listening",
                       "Acoustic",
                       "Humour",
                       "Speech",
                       "Chanson",
                       "Opera",
                       "Chamber Music",
                       "Sonata",
                       "Symphony",
                       "Booty Bass",
                       "Primus",
                       "Porn Groove",
                       "Satire"
                       };

const int genre_count = 111;


#endif /* __GENRE_H__ */


